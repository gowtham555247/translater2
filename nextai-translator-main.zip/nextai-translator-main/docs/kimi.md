How to Obtain Kimi refresh_token and access_token
=================================================

1. Go to the [Kimi official website](https://kimi.moonshot.cn) to log in.
   
2. Obtain the `refresh_token` and `access_token` from the video tutorial below and fill them into the settings box, make sure not to reverse them!!!!!!!!!!!!!!!!!!!!!!
   
  https://github.com/nextai-translator/nextai-translator/assets/1206493/bd5d13aa-9469-4075-bbae-f490cd6667cd

  ![settings](https://github.com/nextai-translator/nextai-translator/assets/1206493/d04a46c5-68c6-44bb-b230-ba8b072fd23d)

