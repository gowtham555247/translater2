How to obtain the `refresh_token` and `token` for ChatGLM
=========================================================

1. Go to the [ChatGLM official website](https://chatglm.cn) to log in.

2. Follow the video tutorial below to obtain the `refresh_token` and `token`, and fill them into the settings box. Make sure not to fill them in reverse!!!!!!!!!!!!

https://github.com/nextai-translator/nextai-translator/assets/1206493/4ee6b295-6a15-4a75-b071-b70b669d5dec

<img width="732" alt="image" src="https://github.com/nextai-translator/nextai-translator/assets/1206493/3ca65ed0-dab8-4101-a2e0-4d346b885461">
