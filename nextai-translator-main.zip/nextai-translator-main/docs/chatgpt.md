FAQ
===

# Q: What should be done when encountering the following error?

<img width="704" alt="image" src="https://github.com/nextai-translator/nextai-translator/assets/1206493/be75f564-21ba-4531-8875-7cd5e8bc554b">

Solution:

  Please log in to [ChatGPT](https://chat.openai.com/) and start a new conversation. Send a few characters randomly, wait for it to respond normally, then return to NextAI Translator and try again, for example:
  
  https://github.com/nextai-translator/nextai-translator/assets/1206493/e0d04d55-d1c3-452c-8b70-55dc2167540e
