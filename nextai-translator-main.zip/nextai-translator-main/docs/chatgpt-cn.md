FAQ
===

# Q: 遇到了如下报错该怎么办？

<img width="704" alt="image" src="https://github.com/nextai-translator/nextai-translator/assets/1206493/be75f564-21ba-4531-8875-7cd5e8bc554b">


解决方案：

  请登录到 [ChatGPT](https://chat.openai.com/) 新建一个对话，随便发送几个字符，等待其正常返回，然后回到 NextAI Translator 重试，例如:

  https://github.com/nextai-translator/nextai-translator/assets/1206493/e0d04d55-d1c3-452c-8b70-55dc2167540e

