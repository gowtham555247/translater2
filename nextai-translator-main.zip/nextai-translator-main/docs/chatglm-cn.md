如何获取 智谱清言（ChatGLM）的 refresh_token 和 token
=================================================

1. 去 [智谱清言官网](https://chatglm.cn) 登录

2. 根据下面视频教程获取 `refresh_token` 和 `token` 填入设置框中，千万别填反了！！！！！！！！！！！！！！

https://github.com/nextai-translator/nextai-translator/assets/1206493/4ee6b295-6a15-4a75-b071-b70b669d5dec

<img width="732" alt="image" src="https://github.com/nextai-translator/nextai-translator/assets/1206493/3ca65ed0-dab8-4101-a2e0-4d346b885461">
