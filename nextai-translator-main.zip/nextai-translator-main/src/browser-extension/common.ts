export const optionsPageOpenaiAPIKeyPromotionIDKey = 'optionsPage:openaiAPIKeyPromotionID'
export const optionsPageHeaderPromotionIDKey = 'optionsPage:openaiHeaderPromotionID'
