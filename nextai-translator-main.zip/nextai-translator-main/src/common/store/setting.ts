import { atom } from 'jotai'

export const showSettingsAtom = atom(false)
